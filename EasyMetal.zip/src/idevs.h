//                       佛光普照
//                      / | | | \
//                     / | | | | \
//
//                       _oo0oo_
//                      o8888888o
//                      88" . "88
//                      (| -_- |)
//                      0\  =  /0
//                    ___/`---'\___
//                  .' \\|     |// '.
//                 / \\|||  :  |||// \
//                / _||||| -:- |||||- \
//               |   | \\\  -  /// |   |
//               | \_|  ''\---/''  |_/ |
//               \  .-\__  '-'  ___/-. /
//             ___'. .'  /--.--\  `. .'___
//          ."" '<  `.___\_<|>_/___.' >' "".
//         | | :  `- \`.;`\ _ /`;.`/ - ` : | |
//         \  \ `_.   \_ __\ /__ _/   .-` /  /
//     =====`-.____`.___ \_____/___.-`___.-'=====
//                       `=---='
//
//
//     ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//
//               佛祖保佑    🙏    上线无BUG
//
//  idevs.h
//  EasyMetal
//
//  Modified by YudaMo on 2019/1/9.
//  Copyright © 2018年 YudaMo.cn@gmail.com. All rights reserved.
//

#ifndef _IDEVS_H_
#define _IDEVS_H_

#include <stdio.h>
#include <string.h>

const char * getMachineName(void);
const bool getGPUAvaliableFlag(void);

#endif /* _IDEVS_H_ */
